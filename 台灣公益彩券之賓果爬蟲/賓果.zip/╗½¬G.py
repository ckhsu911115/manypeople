import requests
import csv
import time
import schedule
import pandas as pd
from datetime import datetime, timedelta
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler

# 初始化資料和餘額
balance = 150
data = []
predicted_next = None
last_draw_term = None

def fetch_latest_data():
    url = "https://api.taiwanlottery.com/TLCAPIWeB/Lottery/LatestBingoResult"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        latest_result = {
            'drawTerm': data['content']['lotteryBingoLatestPost']['drawTerm'],
            'winningNumbers': ",".join(map(str, data['content']['lotteryBingoLatestPost']['openShowOrder'])),
            'highLowTop': data['content']['lotteryBingoLatestPost']['prizeNum'].get('highLow', '－')
        }
        return latest_result
    else:
        return None

def append_to_csv(result, filename):
    file_exists = False
    try:
        with open(filename, 'r', newline='', encoding='utf-8') as file:
            file_exists = True
    except FileNotFoundError:
        pass

    with open(filename, mode='a', newline='', encoding='utf-8') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow(['drawTerm', 'winningNumbers', 'highLowTop'])
        writer.writerow([result['drawTerm'], result['winningNumbers'], result['highLowTop']])
        print(f"Appended draw term {result['drawTerm']} to {filename}")

def update_data(draw_term, winning_numbers, highLowTop):
    num_small = sum(1 for num in winning_numbers if int(num) <= 40)
    num_large = sum(1 for num in winning_numbers if int(num) > 40)
    highLowTop_value = 1 if highLowTop == '大' else 0 if highLowTop == '小' else 2
    data.append({'drawTerm': draw_term, 'num_small': num_small, 'num_large': num_large, 'highLowTop': highLowTop_value})

def train_models(df):
    X = df[['num_small', 'num_large']]
    y = df['highLowTop']

    print(f"Training with {len(df)} data points.")

    if len(set(y)) < 2:
        print(f"Not enough classes to train models: {set(y)}")
        return None, None

    scaler = StandardScaler().fit(X)
    X_scaled = scaler.transform(X)

    models = {
        "Logistic Regression": LogisticRegression(),
        "Random Forest": RandomForestClassifier(),
        "Gradient Boosting": GradientBoostingClassifier(),
        "SVM": SVC(probability=True),
        "Neural Network": MLPClassifier(max_iter=1000)
    }
    for name, model in models.items():
        model.fit(X_scaled, y)

    return models, scaler

def predict_next(models, scaler, num_small, num_large):
    X_test = pd.DataFrame([[num_small, num_large]], columns=['num_small', 'num_large'])
    X_test_scaled = scaler.transform(X_test)
    predictions = {}
    for name, model in models.items():
        probabilities = model.predict_proba(X_test_scaled)[0]
        large_prob = probabilities[1]
        small_prob = probabilities[0]
        none_prob = probabilities[2] if len(probabilities) > 2 else 0
        predictions[name] = {
            'large_probability': large_prob,
            'small_probability': small_prob,
            'none_probability': none_prob
        }
    return predictions

def decide_bet(predictions):
    avg_predictions = {
        'large_probability': 0,
        'small_probability': 0,
        'none_probability': 0
    }
    for result in predictions.values():
        avg_predictions['large_probability'] += result['large_probability']
        avg_predictions['small_probability'] += result['small_probability']
        avg_predictions['none_probability'] += result['none_probability']
    for key in avg_predictions:
        avg_predictions[key] /= len(predictions)

    bet_choice = max(avg_predictions, key=avg_predictions.get)
    bet_prob = avg_predictions[bet_choice]

    if bet_choice == 'none_probability':
        return '-', 0
    elif bet_choice == 'large_probability':
        return '大', bet_prob
    else:
        return '小', bet_prob

def update_balance(prediction, actual_result):
    global balance
    bet_amount = 150
    result = "沒下"
    if prediction != '-':
        balance -= bet_amount
        if (actual_result == 1 and prediction == '大') or (actual_result == 0 and prediction == '小'):
            balance += 900
            result = "贏錢"
        else:
            result = "輸錢"
    return balance, result

def process_draw(draw_term, winning_numbers_str, highLowTop):
    global balance, predicted_next
    try:
        winning_numbers = list(map(int, winning_numbers_str.split(',')))
        update_data(draw_term, winning_numbers, highLowTop)

        if predicted_next:
            actual_result = data[-1]['highLowTop']
            balance, result = update_balance(predicted_next['prediction'], actual_result)
            print("\n---")
            print(f"上期數據:")
            print(f"期數: {predicted_next['drawTerm']}, 預測: {predicted_next['prediction']}, 實際結果: {actual_result}, 餘額: {balance}, 結果: {result}")
            print("---")

        df = pd.DataFrame(data)
        models, scaler = train_models(df)
        if models is not None:
            num_small = data[-1]['num_small']
            num_large = data[-1]['num_large']
            predictions = predict_next(models, scaler, num_small, num_large)

            for model_name, prediction in predictions.items():
                print(f"模型: {model_name}, 期數: {draw_term + 1}, 大的機率: {prediction['large_probability']:.2f}, 小的機率: {prediction['small_probability']:.2f}, 無的機率: {prediction['none_probability']:.2f}")

            prediction, _ = decide_bet(predictions)
            predicted_next = {'drawTerm': draw_term + 1, 'prediction': prediction}

            print("---")
            print("下期預測:")
            print(f"下期預測 - 期數: {draw_term + 1}, 預測: {prediction}")

    except Exception as e:
        print(f"Error processing draw {draw_term}: {e}")

def fetch_and_predict():
    global last_draw_term
    result = fetch_latest_data()
    if result:
        if result['drawTerm'] == last_draw_term:
            print(f"Draw term {result['drawTerm']} is the same as last time, waiting 10 seconds before retrying.")
            time.sleep(10)
            fetch_and_predict()
        else:
            last_draw_term = result['drawTerm']
            append_to_csv(result, "new_open.csv")
            process_draw(result['drawTerm'], result['winningNumbers'], result['highLowTop'])
    else:
        print("Failed to fetch latest data, retrying in 10 seconds.")
        time.sleep(10)
        fetch_and_predict()

def schedule_jobs():
    start_time = datetime.strptime("07:05", "%H:%M")
    end_time = datetime.strptime("23:55", "%H:%M")
    delta = timedelta(minutes=5)
    jobs = []

    while start_time <= end_time:
        job_time = (start_time + timedelta(seconds=120)).strftime("%H:%M:%S")
        jobs.append(job_time)
        schedule.every().day.at(job_time).do(fetch_and_predict)
        start_time += delta

    return jobs

def main():
    global predicted_next
    try:
        df = pd.read_csv('lottery_data_100_days.csv')
        print("Loaded historical data columns:", df.columns)
        for index, row in df.iterrows():
            draw_term = row['drawTerm']
            winning_numbers_str = row['winningNumbers']
            highLowTop = row['highLowTop']
            update_data(draw_term, list(map(int, winning_numbers_str.split(','))), highLowTop)
        print("Successfully loaded historical data")
    except FileNotFoundError:
        print("lottery_data_100_days.csv not found. Exiting.")
        return
    except KeyError as e:
        print(f"Error loading historical data: {e}")
        return

    if len(data) > 1:
        df = pd.DataFrame(data)
        num_small = df.iloc[-1]['num_small']
        num_large = df.iloc[-1]['num_large']
        models, scaler = train_models(df)
        if models is not None:
            predictions = predict_next(models, scaler, num_small, num_large)
            print("\n---")
            print("初始預測:")
            for model_name, prediction in predictions.items():
                print(f"模型: {model_name}, 大的機率: {prediction['large_probability']:.2f}, 小的機率: {prediction['small_probability']:.2f}, 無的機率: {prediction['none_probability']:.2f}")
            prediction, _ = decide_bet(predictions)
            predicted_next = {'drawTerm': df.iloc[-1]['drawTerm'] + 1, 'prediction': prediction}
            print(f"初始預測: {prediction}")
            print("---")

    jobs = schedule_jobs()
    print(f"Scheduled jobs: {jobs}")

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    main()
