const express = require('express');
const bodyParser = require('body-parser');
const db = require('./db');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 用户注册
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const query = 'INSERT INTO users (username, password) VALUES (?, ?)';
    db.query(query, [username, password], (err, result) => {
        if (err) {
            res.status(500).send('Error registering user');
        } else {
            res.send('Registration successful');
        }
    });
});

// 用户登录
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = 'SELECT * FROM users WHERE username = ?';
    db.query(query, [username], (err, results) => {
        if (err) {
            res.status(500).send('Error logging in');
        } else if (results.length === 0) {
            res.status(404).send('No user found');
        } else {
            const user = results[0];
            if (password === user.password) {
                res.json({ message: 'Login successful', userId: user.id });
            } else {
                res.status(401).send('Invalid credentials');
            }
        }
    });
});

// 获取好友列表
app.get('/friends', (req, res) => {
    const userId = req.query.userId;
    const query = `
        SELECT u.id, u.username FROM users u
        JOIN friends f ON (u.id = f.friend_id OR u.id = f.user_id)
        WHERE (f.user_id = ? OR f.friend_id = ?) AND u.id != ?
    `;
    db.query(query, [userId, userId, userId], (err, results) => {
        if (err) {
            res.status(500).send('Error fetching friends');
        } else {
            res.json(results);
        }
    });
});

// 获取历史消息
app.get('/messages', (req, res) => {
    const { userId, friendId } = req.query;
    const query = `
        SELECT * FROM messages
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ORDER BY created_at
    `;
    db.query(query, [userId, friendId, friendId, userId], (err, results) => {
        if (err) {
            res.status(500).send('Error fetching messages');
        } else {
            res.json(results);
        }
    });
});

// 发送好友请求
app.post('/send-friend-request', (req, res) => {
    const { senderId, receiverId } = req.body;
    console.log(`Received friend request from ${senderId} to ${receiverId}`);
    const query = 'INSERT INTO friend_requests (sender_id, receiver_id) VALUES (?, ?)';
    db.query(query, [senderId, receiverId], (err, result) => {
        if (err) {
            console.error('Error sending friend request', err);
            res.status(500).send('Error sending friend request');
        } else {
            console.log('Friend request sent successfully');
            res.send('Friend request sent successfully');
        }
    });
});

// 响应好友请求
app.post('/respond-friend-request', (req, res) => {
    const { requestId, status } = req.body;
    const query = 'UPDATE friend_requests SET status = ? WHERE id = ?';
    db.query(query, [status, requestId], (err, result) => {
        if (err) {
            res.status(500).send('Error responding to friend request');
        } else {
            if (status === 'accepted') {
                const getRequestQuery = 'SELECT sender_id, receiver_id FROM friend_requests WHERE id = ?';
                db.query(getRequestQuery, [requestId], (err, results) => {
                    if (err) {
                        res.status(500).send('Error fetching friend request');
                    } else {
                        const { sender_id, receiver_id } = results[0];
                        const addFriendQuery = 'INSERT INTO friends (user_id, friend_id) VALUES (?, ?), (?, ?)';
                        db.query(addFriendQuery, [sender_id, receiver_id, receiver_id, sender_id], (err, result) => {
                            if (err) {
                                res.status(500).send('Error adding friend');
                            } else {
                                res.send('Friend request accepted and friend added');
                            }
                        });
                    }
                });
            } else {
                res.send('Friend request responded');
            }
        }
    });
});

// 获取好友请求
app.get('/friend-requests', (req, res) => {
    const userId = req.query.userId;
    const query = `
        SELECT fr.id, u.username AS sender_username 
        FROM friend_requests fr
        JOIN users u ON fr.sender_id = u.id
        WHERE fr.receiver_id = ? AND fr.status = 'pending'
    `;
    db.query(query, [userId], (err, results) => {
        if (err) {
            res.status(500).send('Error fetching friend requests');
        } else {
            res.json(results);
        }
    });
});

// 查找用户
app.get('/find-user', (req, res) => {
    const username = req.query.username;
    const query = 'SELECT id FROM users WHERE username = ?';
    db.query(query, [username], (err, results) => {
        if (err) {
            res.status(500).send('Error finding user');
        } else if (results.length === 0) {
            res.json({ userId: null });
        } else {
            res.json({ userId: results[0].id });
        }
    });
});

// 静态文件服务
app.use(express.static('client'));

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
