const WebSocket = require('ws');
const db = require('./db');
const wss = new WebSocket.Server({ port: 8080 });

const clients = new Map();

wss.on('connection', (ws) => {
    console.log('New client connected');

    ws.on('message', (message) => {
        const messageData = JSON.parse(message);
        const { senderId, receiverId, message: text } = messageData;

        // 存儲消息到數據庫
        const query = 'INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)';
        db.query(query, [senderId, receiverId, text], (err, result) => {
            if (err) {
                console.error('Error saving message to database', err);
            } else {
                console.log('Message saved to database');
            }
        });

        // 將消息轉發給指定的接收者
        const receiverWs = clients.get(receiverId);
        if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
            receiverWs.send(JSON.stringify({ senderId, message: text }));
        }

        // 將消息發回給發送者以顯示在自己的對話框中
        if (ws.readyState === WebSocket.OPEN) {
            ws.send(JSON.stringify({ senderId, message: text }));
        }
    });

    ws.on('close', () => {
        clients.forEach((clientWs, clientId) => {
            if (clientWs === ws) {
                clients.delete(clientId);
            }
        });
        console.log('Client disconnected');
    });
});

function registerClient(clientId, ws) {
    clients.set(clientId, ws);
}
