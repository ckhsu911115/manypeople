let ws;
let currentUserId;
let currentFriendId;
let currentFriendName;

document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('register-button').addEventListener('click', register);
    document.getElementById('login-button').addEventListener('click', login);
    document.getElementById('send-button').addEventListener('click', sendMessage);
    document.getElementById('add-friend-button').addEventListener('click', sendFriendRequest);
});

function showRegisterPage() {
    document.getElementById('login-page').style.display = 'none';
    document.getElementById('register-page').style.display = 'block';
}

function showLoginPage() {
    document.getElementById('register-page').style.display = 'none';
    document.getElementById('login-page').style.display = 'block';
}

function showHomePage() {
    document.getElementById('chat-page').style.display = 'none';
    document.getElementById('home-page').style.display = 'block';
    loadFriends();
    loadFriendRequests();
}

function showChatPage(friendName) {
    document.getElementById('home-page').style.display = 'none';
    document.getElementById('chat-page').style.display = 'block';
    document.getElementById('chat-friend-name').textContent = friendName;
}

function register() {
    const username = document.getElementById('register-username').value;
    const password = document.getElementById('register-password').value;
    fetch('/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    }).then(response => response.text()).then(data => {
        alert(data);
        if (data === 'Registration successful') {
            showLoginPage();
        }
    });
}

function login() {
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;
    fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    }).then(response => response.json()).then(data => {
        if (data.message === 'Login successful') {
            currentUserId = data.userId;
            document.getElementById('username-display').textContent = username;
            showHomePage();
            setupWebSocket();
        } else {
            alert(data.message);
        }
    });
}

function loadFriends() {
    fetch(`/friends?userId=${currentUserId}`)
        .then(response => response.json())
        .then(friends => {
            const friendList = document.getElementById('friend-list');
            friendList.innerHTML = '';
            friends.forEach(friend => {
                const friendItem = document.createElement('div');
                friendItem.textContent = friend.username;
                friendItem.addEventListener('click', () => {
                    currentFriendId = friend.id;
                    currentFriendName = friend.username;
                    document.getElementById('message-list').innerHTML = '';
                    loadMessages(friend.id);
                    showChatPage(friend.username);
                });
                friendList.appendChild(friendItem);
            });
        });
}

function loadFriendRequests() {
    fetch(`/friend-requests?userId=${currentUserId}`)
        .then(response => response.json())
        .then(requests => {
            const requestList = document.getElementById('friend-requests');
            requestList.innerHTML = '';
            requests.forEach(request => {
                const requestItem = document.createElement('div');
                requestItem.textContent = `Friend request from ${request.sender_username}`;
                const acceptButton = document.createElement('button');
                acceptButton.textContent = 'Accept';
                acceptButton.addEventListener('click', () => respondFriendRequest(request.id, 'accepted'));
                const rejectButton = document.createElement('button');
                rejectButton.textContent = 'Reject';
                rejectButton.addEventListener('click', () => respondFriendRequest(request.id, 'rejected'));
                requestItem.appendChild(acceptButton);
                requestItem.appendChild(rejectButton);
                requestList.appendChild(requestItem);
            });
        });
}

function setupWebSocket() {
    ws = new WebSocket('ws://localhost:8080');

    ws.onopen = () => {
        console.log('WebSocket connection opened');
        ws.send(JSON.stringify({ type: 'register', clientId: currentUserId }));
    };

    ws.onmessage = (event) => {
        const messageData = JSON.parse(event.data);
        if (messageData.senderId === currentFriendId || messageData.senderId === currentUserId) {
            const messageList = document.getElementById('message-list');
            const newMessage = document.createElement('div');
            newMessage.textContent = messageData.message;
            messageList.appendChild(newMessage);
        }
    };

    ws.onclose = () => {
        console.log('WebSocket connection closed');
    };
}

function sendMessage() {
    const message = document.getElementById('message').value;
    if (ws && ws.readyState === WebSocket.OPEN) {
        const messageData = {
            senderId: currentUserId,
            receiverId: currentFriendId,
            message: message
        };
        ws.send(JSON.stringify(messageData));
        document.getElementById('message').value = '';
    } else {
        alert('WebSocket connection is not open');
    }
}

function loadMessages(friendId) {
    fetch(`/messages?userId=${currentUserId}&friendId=${friendId}`)
        .then(response => response.json())
        .then(messages => {
            const messageList = document.getElementById('message-list');
            messageList.innerHTML = '';
            messages.forEach(message => {
                const messageItem = document.createElement('div');
                messageItem.textContent = message.message;
                messageList.appendChild(messageItem);
            });
        });
}

function sendFriendRequest() {
    console.log('Send friend request button clicked');
    const friendUsername = document.getElementById('add-friend-username').value;
    fetch(`/find-user?username=${friendUsername}`)
        .then(response => response.json())
        .then(data => {
            console.log('Find user response:', data);
            if (data.userId) {
                const receiverId = data.userId;
                fetch('/send-friend-request', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ senderId: currentUserId, receiverId })
                }).then(response => response.text()).then(data => {
                    console.log('Send friend request response:', data);
                    alert(data);
                    if (data === 'Friend request sent successfully') {
                        alert('提交成功');
                    } else {
                        alert('提交失败');
                    }
                });
            } else {
                alert('User not found');
            }
        });
}

function respondFriendRequest(requestId, status) {
    fetch('/respond-friend-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, status })
    }).then(response => response.text()).then(data => {
        alert(data);
        loadFriendRequests();
        if (status === 'accepted') {
            loadFriends();
        }
    });
}
